//TEST TO SEE IF I CAN READ AND WRITE TO DATABASE
//TEST SUCCESSFUL

const sqlite3 = require('sqlite3').verbose();

var db = new sqlite3.Database('database.db');

let name = "Keith";
let price = 4.0;


// insert one row into the langs table
q = db.run("SELECT username FROM customer WHERE fname = Keith");
db.run("INSERT INTO pizza VALUES ('Meatfeast', 'M', 'Pepp/Chick/Saus', '5'");
console.log(q);
// close the database connection
db.close();