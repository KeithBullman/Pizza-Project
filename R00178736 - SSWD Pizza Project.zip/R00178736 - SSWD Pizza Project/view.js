//LIBRARIES
const http = require('http');
const fs = require('fs');
const ejs = require('ejs');
const path = require('path');

//PIZZA HOST + PORT
const HOST_NAME = '127.0.0.1';
const PORT_NUM = process.env.PORT || 3000;

//TEMPLATE FILES
const filePath = __dirname + '/views/pages/'; //__dirname is always the current directory, same as ./
const index_path = filePath + 'index.ejs';
const pizza_path = filePath + 'pizza.ejs';
const signup_path = filePath + 'signup.ejs';
const custom_path = filePath + 'custom.ejs';
const cart_path = filePath + 'cart.ejs';
const completed_order = filePath + 'ordercomplete.ejs';
const dead_path = filePath + '404.ejs';

//CREATE IMAGE SERVER
http.createServer(function (request, response) {
    var filePath = '.' + request.url;
    if (filePath === './')
        filePath = './index.html';

    var extname = path.extname(filePath);

    var contentType = 'text/html';

    switch (extname) {
        case '.png':
            contentType = 'images/png';
            break;
        case '.jpg':
            contentType = 'images/jpg';
            break;
    }

    fs.readFile(filePath, function(error, content) {
        response.writeHead(200, { 'Content-Type': contentType });
        response.end(content, 'utf-8');
    });
}).listen(8125);

//CREATE PIZZA SERVER
const server = http.createServer(function (req, res) {
    if (req.url === '/') {

        //HOME PAGE RENDER
        ejs.renderFile(index_path, function (err, data)
        {   console.log(err || data);
            res.end(data);
        });

    }

    else if (req.url === '/pizza') {
        //PIZZA + SIDES RENDER
        ejs.renderFile(pizza_path, function (err, data) {
            console.log(err || data);
            res.end(data);
        });

    }

    else if(req.url === '/signup'){
        //SIGNUP RENDER
        ejs.renderFile(signup_path, function (err, data){
            console.log(err || data);
            res.end(data);
        });
    }

    else if(req.url === '/custom'){
        //CUSTOM PIZZA RENDER
        ejs.renderFile(custom_path, function(err, data){
            console.log(err || data);
            res.end(data);
        });
    }

    else if(req.url === '/cart'){
        //CART RENDER
        ejs.renderFile(cart_path, function(err, data){
            console.log(err || data);
            res.end(data);
        });
    }

    else if(req.url === '/ordercomplete'){
        //COMPLETED ORDER RENDER
        ejs.renderFile(completed_order, function(err, data){
            console.log(err || data);
            res.end(data);
        });
    }

    else {
        //404 ERROR RENDER
        ejs.renderFile(dead_path, function(err, data){
            console.log(err || data);
            res.end(data);
        });
    }
});

server.listen(PORT_NUM, HOST_NAME, function () {
    console.log("Pizza Server is running on: " + HOST_NAME + ":" + PORT_NUM);
});
